-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 19, 2021 at 04:23 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blood_bank_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `fid` int(50) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `e_mail` varchar(100) NOT NULL,
  `u_date` date NOT NULL,
  `content` varchar(500) NOT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`fid`, `fname`, `lname`, `e_mail`, `u_date`, `content`) VALUES
(1, 'Gita', 'Mudliyar', 'gitamm@gmail.com', '2021-07-18', 'Hi, It is very useful');

-- --------------------------------------------------------

--
-- Table structure for table `hospital_profile`
--

CREATE TABLE IF NOT EXISTS `hospital_profile` (
  `h_uname` varchar(100) NOT NULL,
  `hospital_name` varchar(100) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `e_email` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  PRIMARY KEY (`h_uname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospital_profile`
--

INSERT INTO `hospital_profile` (`h_uname`, `hospital_name`, `phone`, `e_email`, `address`, `city`, `state`) VALUES
('Tony', 'KGF', '9090909090', 'gitamudliyar0@gmail.com', 'Janawade Malla, Kantap Plot, Samtanagar, Miraj', 'Miraj', 'MAHARASHTRA'),
('Sony', 'Sony Hospital', '9078679778', 'sony@sony.com', 'Dharavi', 'Mumbai', 'Maharashtra'),
('Uma', '', '', '', '', '', ''),
('Unique', 'Unique Hospital', '9087878767', 'contact@Unique.com', 'M.G.Road', 'Sangli', 'Maharashtra'),
('Aims', 'Aims Hospital', '7867890989', 'aims@gmail.com', 'Pimperi', 'Pune', 'Maharashtra');

-- --------------------------------------------------------

--
-- Table structure for table `h_blood_info`
--

CREATE TABLE IF NOT EXISTS `h_blood_info` (
  `hid` int(50) NOT NULL AUTO_INCREMENT,
  `h_uname` varchar(100) NOT NULL,
  `hospital_name` varchar(100) NOT NULL,
  `blood_group` varchar(50) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `udt` date NOT NULL,
  PRIMARY KEY (`hid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `h_blood_info`
--

INSERT INTO `h_blood_info` (`hid`, `h_uname`, `hospital_name`, `blood_group`, `quantity`, `udt`) VALUES
(8, 'Sony', 'Sony Hospital', 'B+ ve', '4', '0000-00-00'),
(7, 'Tony', 'KGF', 'A- ve', '23', '0000-00-00'),
(6, 'Aims', 'Aims Hospital', 'B+ ve', '2', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `uname` varchar(100) NOT NULL,
  `pwd` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL,
  `blood_group` varchar(8) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`uname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`uname`, `pwd`, `role`, `blood_group`, `created_at`) VALUES
('Tony', 'tONY', 'hospital', '', '2021-07-18'),
('Gayatri', 'Gayatri', 'receiver', 'O+ ve', '2021-07-18'),
('Sony', 'Sony', 'hospital', ' ', '2021-07-18'),
('Uma', 'Uma', 'hospital', ' ', '2021-07-18'),
('Rama', 'Rama', 'receiver', 'O+ ve', '2021-07-18'),
('Unique', 'Unique', 'hospital', ' ', '2021-07-18'),
('Aims', 'Aims', 'hospital', ' ', '2021-07-18'),
('Gita', 'Gita', 'receiver', 'A+ ve', '2021-07-19');

-- --------------------------------------------------------

--
-- Table structure for table `receiver_profile`
--

CREATE TABLE IF NOT EXISTS `receiver_profile` (
  `r_uname` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `age` int(4) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `aadhar_id` varchar(20) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `e_email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  PRIMARY KEY (`r_uname`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receiver_profile`
--

INSERT INTO `receiver_profile` (`r_uname`, `fname`, `lname`, `age`, `gender`, `aadhar_id`, `phone`, `e_email`, `address`, `city`, `state`) VALUES
('Gayatri', 'Gayatri', 'Patil', 28, 'Female', '895775789999', '9078679976', 'gayu@gmail.com', 'ECR', 'Chennai', 'Tamil Nadu'),
('Rama', 'Rama', 'Sharma', 23, 'Female', '979799776776', '8021094915', 'ramarama@gmail.com', 'Shivaji Nagar', 'Miraj', 'MAHARASHTRA'),
('Gita', 'Gita', 'Mudliyar', 23, 'Female', '187878789656', '9051094915', 'gitamudliyar@gmail.com', 'Samtanagar', 'Miraj', 'MAHARASHTRA');

-- --------------------------------------------------------

--
-- Table structure for table `request_sample`
--

CREATE TABLE IF NOT EXISTS `request_sample` (
  `rid` int(50) NOT NULL AUTO_INCREMENT,
  `f_uname` varchar(100) NOT NULL,
  `from_u` varchar(100) NOT NULL,
  `t_uname` varchar(100) NOT NULL,
  `to_u` varchar(100) NOT NULL,
  `mdate` date NOT NULL,
  `blood_group` varchar(20) NOT NULL,
  `quantity` varchar(10) NOT NULL,
  `udate` date NOT NULL,
  `contents` varchar(200) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `request_sample`
--

INSERT INTO `request_sample` (`rid`, `f_uname`, `from_u`, `t_uname`, `to_u`, `mdate`, `blood_group`, `quantity`, `udate`, `contents`) VALUES
(1, 'Rama', 'Rama Sharma', 'Tony', 'KGF', '2021-07-18', 'B -ve', '2', '0000-00-00', 'hi'),
(3, 'Gayatri', 'Rama Sharma', 'Sony', 'Sony Hospital', '2021-07-18', 'B- ve', '2', '0000-00-00', 'Hi'),
(4, 'Gayatri', 'Rama Sharma', 'Sony', 'Sony Hospital', '2021-07-18', 'B- ve', '2', '0000-00-00', 'Hi'),
(10, 'Gita', 'Gita Mudliyar', 'Tony', 'KGF', '2021-07-19', 'A+ ve', '1', '0000-00-00', 'I need it within 2 days'),
(5, 'Gayatri', 'Rama Sharma', 'Sony', 'Sony Hospital', '2021-07-18', 'B- ve', '2', '0000-00-00', 'Hi'),
(6, 'Gayatri', 'Rama Sharma', 'Aims', 'Aims Hospital', '2021-07-18', 'AB- ve', '2', '0000-00-00', 'Hello'),
(7, 'Gayatri', 'Rama Sharma', 'Sony', 'Sony Hospital', '2021-07-18', 'A+ ve', '2', '0000-00-00', 'Hello'),
(8, 'Gayatri', 'Rama Sharma', 'Tony', 'KGF', '2021-07-18', 'Bombay Blood Group', '4', '0000-00-00', 'Urgent'),
(9, 'Gayatri', 'Gayatri Patil', 'Tony', 'KGF', '2021-07-18', 'Bombay Blood Group', '2', '0000-00-00', 'Its urgent');
